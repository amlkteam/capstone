---
name: Feature/Enhancement request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

To be removed, once it is done: Please add the appropriate label to this ticket, e.g. feature or enhancement.

**Is your feature/enhancement request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
Please provide suggestions on how to solve the problem, how to implement the idea.

**Additional context**
Add any other context or screenshots about the feature/enhancement request.
